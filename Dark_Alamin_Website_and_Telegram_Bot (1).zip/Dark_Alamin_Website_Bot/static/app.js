const $=id=>document.getElementById(id);
async function api(url,data){const r=await fetch(url,{method:data?'POST':'GET',headers:{'Content-Type':'application/json'},body:data?JSON.stringify(data):undefined});let j={};try{j=await r.json()}catch{}if(!r.ok)throw Error(j.error||'Request failed');return j}
function showMember(exp){$('loginPanel').classList.add('hidden');$('memberPanel').classList.remove('hidden');$('expiry').textContent=exp}
$('loginForm').addEventListener('submit',async e=>{e.preventDefault();$('loginMsg').textContent='Checking...';try{const j=await api('/api/login',{key:$('vipKey').value});showMember(j.expires)}catch(x){$('loginMsg').textContent=x.message}});
$('logout').onclick=async()=>{await api('/api/logout',{});$('memberPanel').classList.add('hidden');$('loginPanel').classList.remove('hidden')};
$('adminLogin').addEventListener('submit',async e=>{e.preventDefault();try{await api('/api/admin/login',{password:$('adminPass').value});$('adminArea').classList.remove('hidden');$('adminMsg').textContent='';await refresh()}catch(x){$('adminMsg').textContent=x.message}});
async function refresh(){const j=await api('/api/admin/stats');$('totalKeys').textContent=j.total_keys;$('unused').textContent=j.unused;$('botUsers').textContent=j.bot_users;$('webVips').textContent=j.web_vips;$('keyList').innerHTML=j.keys.map(k=>`${k.code} · ${k.days} days · ${k.used_by===null?'Unused':'Used'}`).join('<br>')||'No keys yet'}
$('genForm').addEventListener('submit',async e=>{e.preventDefault();try{const j=await api('/api/admin/generate',{days:$('days').value});$('newKey').textContent='New Key: '+j.key;await refresh()}catch(x){$('adminMsg').textContent=x.message}});
(async()=>{try{const j=await api('/api/me');showMember(j.expires)}catch{}})();
